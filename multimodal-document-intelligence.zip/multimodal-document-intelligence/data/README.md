# Data and licensing

The included sample document is synthetic and was created specifically for this repository. It contains no personal or employer-confidential information. Do not add private workplace files to a public repository. Keep uploaded files in memory by default; this MVP does not persist uploads to disk.
