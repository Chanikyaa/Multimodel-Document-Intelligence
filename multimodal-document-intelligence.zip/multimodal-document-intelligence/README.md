# Multimodal Document Intelligence

An evidence-first document intelligence API for PDFs, text files, tables, and images. It preserves source/page provenance, supports optional OCR and vision adapters, retrieves relevant evidence, and extracts typed fields with source-line traceability.

> **Status:** local MVP. Automated tests validate the parsing, retrieval, extraction, and API paths. It is not a hardened public production service. Mock vision does not interpret images.

## Features

- PDF text and table extraction with page references (`pdfplumber`).
- TXT and Markdown ingestion; image upload validation (`Pillow`).
- Optional Tesseract OCR for image uploads.
- Optional OpenAI-compatible vision captioner; mock mode is default and does not require a key.
- Lexical evidence retrieval with an explicit no-evidence abstention.
- Typed extraction of labelled string, number, date, and boolean fields with source snippets.
- FastAPI endpoints and a minimal browser UI; automatic API docs at `/docs`.
- Upload size/type validation, Docker, GitHub Actions, tests, architecture/security docs.

## Non-goals in this MVP

No robust chart QA, no OCR on rendered scanned-PDF pages, no semantic/vector search, no persistent storage, no authentication/tenant isolation, no production rate limiting, and no claims of evaluated visual accuracy.

## Architecture

See [architecture](docs/architecture.md), [evaluation plan](docs/evaluation.md), and [security notes](docs/security.md).

```mermaid
flowchart LR
  A[PDF / text / image] --> B[Validation and parsers]
  B --> C[Page-aware evidence]
  C --> D[In-memory store]
  D --> E[Lexical retrieval]
  D --> F[Typed field extraction]
  E --> G[Evidence response / abstention]
  F --> H[Validated JSON + source line]
```

## Requirements and setup

Python 3.10+ is recommended. Tesseract must be installed separately for OCR; live vision is optional and may incur API costs.

```bash
python -m venv .venv
source .venv/bin/activate
python -m pip install -e ".[dev]"
pytest -q
uvicorn docintel.api:app --reload
```

Windows PowerShell activation: `.venv\Scripts\Activate.ps1`.

Open `http://127.0.0.1:8000/` for the demo or `http://127.0.0.1:8000/docs` for interactive API docs.

## Configuration

Copy `.env.example` to `.env` and export the values in your shell; this project does not load `.env` automatically.

| Variable | Default | Purpose |
|---|---|---|
| `MAX_UPLOAD_MB` | documented cap is 15 MiB | Future deployment configuration; current hard cap is 15 MiB in code |
| `OCR_ENABLED` | `false` | Documented optional OCR setting; API accepts `?ocr=true` per upload |
| `VISION_PROVIDER` | `mock` | `mock` or `openai-compatible` |
| `OPENAI_API_KEY` | empty | Required only for live vision calls |
| `OPENAI_BASE_URL` | OpenAI API base | Compatible API endpoint |
| `OPENAI_VISION_MODEL` | `gpt-4o-mini` | Vision model name |

## API examples

### Upload

```bash
curl -F "file=@data/sample/report.txt" http://127.0.0.1:8000/documents
```

Response includes a `document_id`, page count, content item counts, and warnings.

### Query

```bash
curl -X POST http://127.0.0.1:8000/query \
  -H 'Content-Type: application/json' \
  -d '{"question":"What is the project budget?","top_k":5}'
```

### Extract typed fields

Use the `document_id` returned by upload:

```bash
curl -X POST http://127.0.0.1:8000/extract \
  -H 'Content-Type: application/json' \
  -d '{"document_id":"YOUR_ID","fields":{"Report date":"date","Project budget":"number","Approved":"boolean"}}'
```

### CLI

```bash
docintel ingest data/sample/report.txt
docintel query data/sample/report.txt "What is the project budget?"
```

## OCR and vision options

- OCR for uploaded images: install `python -m pip install -e ".[ocr]"`, install the Tesseract system binary, then upload with `?ocr=true`.
- Live image captioning: set `VISION_PROVIDER=openai-compatible` and `OPENAI_API_KEY`. The image is sent to the configured endpoint; confirm your privacy and provider terms before using sensitive files. Calls may incur cost.
- Mock mode is safe for offline tests but emits a generic note, not an image interpretation.
- Scanned PDF page OCR and robust charts/diagrams understanding are not implemented yet.

## Verification and evaluation

Run `pytest -q`. CI repeats the suite on pushes and pull requests. Tests cover PDF/text ingestion, file validation, evidence provenance, retrieval/abstention, typed extraction, and the API flow. See [evaluation methodology](docs/evaluation.md) for a proper labelled benchmark plan. No quality/latency claims are made until that benchmark is run.

## Docker

```bash
docker compose up --build
```

## Security and privacy

Uploads are kept in memory, not persisted, but there is no authentication, tenant isolation, rate limiting, malware scanning, or public-deployment hardening. Do not expose this MVP to the internet with sensitive files. See [security notes](docs/security.md).

## Interview and portfolio

Read [career-readiness guide](docs/career-readiness.md) for role mapping, demo script, architecture explanation, resume templates, interview questions, and system-design scenarios. Use only measured results in your resume.

## GitHub publication

```bash
git init
git add .
git status
git commit -m "Build multimodal document intelligence MVP"
git branch -M main
git remote add origin YOUR_GITHUB_REPOSITORY_URL
git push -u origin main
```

Review the repository and remove any private data before publishing. This project has not been published to GitHub by this build process.
