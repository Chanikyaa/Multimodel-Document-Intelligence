"""Optional visual-description adapters. The default adapter never claims to see image contents."""
from __future__ import annotations
import base64, os
import httpx

class MockCaptioner:
    def describe(self, image_bytes: bytes) -> str:
        return "Image evidence available; configure a vision provider to describe its contents."

class OpenAICompatibleCaptioner:
    """Optional OpenAI-compatible vision API. May incur provider charges."""
    def __init__(self, api_key: str | None = None, base_url: str | None = None, model: str | None = None, timeout: float = 30.0):
        self.api_key = api_key or os.getenv("OPENAI_API_KEY", "")
        self.base_url = (base_url or os.getenv("OPENAI_BASE_URL", "https://api.openai.com/v1")).rstrip("/")
        self.model = model or os.getenv("OPENAI_VISION_MODEL", "gpt-4o-mini")
        self.timeout = timeout
        if not self.api_key:
            raise ValueError("OPENAI_API_KEY is required for the vision provider")

    def describe(self, image_bytes: bytes) -> str:
        encoded = base64.b64encode(image_bytes).decode("ascii")
        response = httpx.post(
            f"{self.base_url}/chat/completions", timeout=self.timeout,
            headers={"Authorization": f"Bearer {self.api_key}"},
            json={"model": self.model, "temperature": 0, "messages":[{"role":"user","content":[{"type":"text","text":"Describe the visible content concisely. Separate observation from uncertainty; do not infer facts that are not visible."},{"type":"image_url","image_url":{"url":f"data:image/png;base64,{encoded}"}}]}]},
        )
        response.raise_for_status()
        payload = response.json()
        try:
            return str(payload["choices"][0]["message"]["content"]).strip()
        except (KeyError, IndexError, TypeError) as exc:
            raise ValueError("Vision provider returned an unexpected response schema") from exc

def build_captioner():
    provider = os.getenv("VISION_PROVIDER", "mock").lower()
    if provider == "mock":
        return MockCaptioner()
    if provider in {"openai", "openai-compatible"}:
        return OpenAICompatibleCaptioner()
    raise ValueError(f"Unknown VISION_PROVIDER: {provider}")
