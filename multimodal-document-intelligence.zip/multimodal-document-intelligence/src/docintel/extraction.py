"""Evidence-linked field extraction with conservative type validation."""
from __future__ import annotations
import re
from datetime import date
from .ingest import DocumentStore
from .models import ExtractionResponse

NUMBER_RE = re.compile(r"(?<![A-Za-z])[-+]?\d+(?:,\d{3})*(?:\.\d+)?")
DATE_RES = [re.compile(r"\b\d{4}-\d{2}-\d{2}\b"), re.compile(r"\b\d{1,2}/\d{1,2}/\d{4}\b")]

def extract_fields(store: DocumentStore, document_id: str, fields: dict[str, str]) -> ExtractionResponse:
    evidence_items = store.for_document(document_id)
    full_text = "\n".join(item.text for item in evidence_items if item.content_type in {"text", "table", "ocr_text"})
    values: dict[str, object] = {}
    evidence: dict[str, str] = {}
    missing: list[str] = []
    for name, kind in fields.items():
        if kind not in {"string", "number", "date", "boolean"}:
            raise ValueError(f"Unsupported type for {name}: {kind}")
        # Field name is used as a case-insensitive label, not as executable syntax.
        pattern = re.compile(r"(?im)^\s*" + re.escape(name) + r"\s*[:=]\s*(.+?)\s*$")
        match = pattern.search(full_text)
        if not match:
            missing.append(name)
            continue
        raw = match.group(1).strip().strip(".,;")
        try:
            if kind == "string": value = raw
            elif kind == "number":
                number = NUMBER_RE.search(raw)
                if not number: raise ValueError("no number")
                value = float(number.group(0).replace(",", ""))
                if value.is_integer(): value = int(value)
            elif kind == "date":
                date_match = next((r.search(raw) for r in DATE_RES if r.search(raw)), None)
                if not date_match: raise ValueError("no date")
                value = date.fromisoformat(date_match.group(0)) .isoformat() if "-" in date_match.group(0) else date_match.group(0)
            else:
                normalized = raw.lower()
                if normalized not in {"true", "false", "yes", "no"}: raise ValueError("not boolean")
                value = normalized in {"true", "yes"}
            values[name] = value
            evidence[name] = match.group(0)
        except ValueError:
            missing.append(name)
    return ExtractionResponse(document_id=document_id, values=values, evidence=evidence, missing_fields=missing)
