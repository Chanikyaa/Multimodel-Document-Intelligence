"""Small CLI for local document ingestion and query demos."""
import argparse, json
from pathlib import Path
from .ingest import DocumentStore
from .retrieval import answer_question
from .vision import build_captioner

def main():
    parser = argparse.ArgumentParser(description="Multimodal document intelligence CLI")
    sub = parser.add_subparsers(dest="command", required=True)
    ingest = sub.add_parser("ingest", help="Parse a local document")
    ingest.add_argument("path", type=Path)
    query = sub.add_parser("query", help="Ingest a document and query it in one command")
    query.add_argument("path", type=Path)
    query.add_argument("question")
    args = parser.parse_args()
    content = args.path.read_bytes()
    store = DocumentStore()
    result = store.ingest(args.path.name, content, captioner=build_captioner())
    if args.command == "ingest":
        print(result.model_dump_json(indent=2))
    else:
        print(answer_question(store, args.question).model_dump_json(indent=2))
if __name__ == "__main__": main()
