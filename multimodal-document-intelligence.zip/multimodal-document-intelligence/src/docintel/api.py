"""FastAPI service for upload, retrieval, and schema-constrained extraction."""
from __future__ import annotations
import os
from fastapi import FastAPI, File, HTTPException, UploadFile, Query
from fastapi.responses import HTMLResponse
from .ingest import DocumentStore, MAX_BYTES
from .models import QueryRequest, QueryResponse, ExtractionRequest, ExtractionResponse
from .retrieval import answer_question
from .extraction import extract_fields
from .vision import build_captioner

app = FastAPI(title="Multimodal Document Intelligence", version="0.1.0", description="Evidence-first parsing and retrieval for PDFs, text, tables, and images.")
store = DocumentStore()
captioner = None
try:
    captioner = build_captioner()
except ValueError:
    # Missing optional provider credentials should not prevent local/mock API startup.
    captioner = None

@app.get("/health")
def health():
    return {"status":"ok", "documents":len(store.documents), "vision_provider":os.getenv("VISION_PROVIDER", "mock")}

@app.get("/", response_class=HTMLResponse)
def home():
    return """<!doctype html><html><head><meta charset="utf-8"><title>DocIntel</title><style>body{font:16px system-ui;max-width:850px;margin:3rem auto;padding:0 1rem}input,textarea,button{font:inherit;padding:.6rem;margin:.3rem 0;width:100%;box-sizing:border-box}pre{white-space:pre-wrap;background:#f4f4f4;padding:1rem;border-radius:8px}.row{display:grid;grid-template-columns:1fr 1fr;gap:1rem}</style></head><body><h1>Multimodal Document Intelligence</h1><p>Upload a PDF, text file, or image; query the extracted evidence. Mock mode requires no API key.</p><h2>1. Ingest</h2><input id="file" type="file" accept=".pdf,.txt,.md,.png,.jpg,.jpeg,.webp"><button onclick="upload()">Upload and parse</button><pre id="uploadout">No document uploaded yet.</pre><h2>2. Ask a question</h2><textarea id="question" rows="3" placeholder="What is the report date?"></textarea><button onclick="ask()">Search evidence</button><pre id="answer">Results appear here.</pre><script>let docId=null;async function upload(){let f=document.getElementById('file').files[0];if(!f)return alert('Choose a file first');let d=new FormData();d.append('file',f);let r=await fetch('/documents', {method:'POST',body:d});let j=await r.json();document.getElementById('uploadout').textContent=JSON.stringify(j,null,2);if(r.ok)docId=j.document_id;else alert(j.detail||'Upload failed')}async function ask(){let q=document.getElementById('question').value;let r=await fetch('/query',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({question:q,top_k:5})});document.getElementById('answer').textContent=JSON.stringify(await r.json(),null,2)}</script></body></html>"""

@app.post("/documents")
async def ingest_document(file: UploadFile = File(...), ocr: bool = Query(False, description="Enable Tesseract OCR for image uploads")):
    filename = file.filename or "upload"
    content = await file.read(MAX_BYTES + 1)
    if len(content) > MAX_BYTES:
        raise HTTPException(status_code=413, detail="File exceeds 15 MiB limit")
    try:
        result = store.ingest(filename, content, ocr_enabled=ocr, captioner=captioner)
        return result.model_dump()
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc

@app.get("/documents")
def list_documents():
    return store.list_documents()

@app.post("/query", response_model=QueryResponse)
def query(request: QueryRequest):
    return answer_question(store, request.question, request.top_k)

@app.post("/extract", response_model=ExtractionResponse)
def extract(request: ExtractionRequest):
    try:
        return extract_fields(store, request.document_id, request.fields)
    except KeyError as exc:
        raise HTTPException(status_code=404, detail="Document not found") from exc
    except ValueError as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc
