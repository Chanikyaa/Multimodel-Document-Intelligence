"""Document parsing with page-aware evidence and graceful optional OCR."""
from __future__ import annotations
import hashlib, io, re
from pathlib import Path
from typing import BinaryIO
from PIL import Image
from .models import Evidence, IngestResult

ALLOWED_EXTENSIONS = {".pdf", ".txt", ".md", ".png", ".jpg", ".jpeg", ".webp"}
MAX_BYTES = 15 * 1024 * 1024

class DocumentStore:
    def __init__(self) -> None:
        self.documents: dict[str, dict] = {}
        self.evidence: list[Evidence] = []

    def ingest(self, filename: str, content: bytes, *, ocr_enabled: bool = False, captioner=None) -> IngestResult:
        ext = Path(filename).suffix.lower()
        if ext not in ALLOWED_EXTENSIONS:
            raise ValueError(f"Unsupported file type: {ext or '(no extension)'}")
        if not content:
            raise ValueError("Uploaded file is empty")
        if len(content) > MAX_BYTES:
            raise ValueError("File exceeds 15 MiB limit")
        doc_id = hashlib.sha256(filename.encode() + b"\0" + content).hexdigest()[:16]
        if doc_id in self.documents:
            return self.documents[doc_id]["result"]
        items: list[Evidence] = []
        warnings: list[str] = []
        tables: list[dict] = []
        image_count = 0
        pages = 1
        if ext == ".pdf":
            try:
                import pdfplumber
                with pdfplumber.open(io.BytesIO(content)) as pdf:
                    pages = len(pdf.pages)
                    for page_no, page in enumerate(pdf.pages, 1):
                        text = (page.extract_text() or "").strip()
                        if text:
                            items.append(Evidence(document_id=doc_id, filename=filename, page=page_no, content_type="text", text=text))
                        try:
                            for table_idx, table in enumerate(page.extract_tables() or [], 1):
                                cleaned = [[str(cell or "").strip() for cell in row] for row in table if row]
                                if cleaned:
                                    rendered = " | ".join(" ; ".join(row) for row in cleaned)
                                    items.append(Evidence(document_id=doc_id, filename=filename, page=page_no, content_type="table", text=rendered, metadata={"table_index": table_idx, "rows": len(cleaned)}))
                                    tables.append({"page": page_no, "rows": cleaned})
                        except Exception as exc:
                            warnings.append(f"Page {page_no}: table extraction failed ({type(exc).__name__})")
                # Extract embedded images separately. PyMuPDF is optional, so PDFs still work without it.
                try:
                    import fitz
                    pdfdoc = fitz.open(stream=content, filetype="pdf")
                    for page_index, page in enumerate(pdfdoc, 1):
                        for image_idx, image_info in enumerate(page.get_images(full=True), 1):
                            xref = image_info[0]
                            image_bytes = pdfdoc.extract_image(xref).get("image", b"")
                            if not image_bytes:
                                continue
                            image_count += 1
                            caption = captioner.describe(image_bytes) if captioner else "Embedded image; visual description not configured."
                            items.append(Evidence(document_id=doc_id, filename=filename, page=page_index, content_type="image", text=caption, metadata={"image_index": image_idx, "caption_source": "configured_adapter" if captioner else "placeholder"}))
                    pdfdoc.close()
                except ImportError:
                    warnings.append("PyMuPDF not installed; embedded image extraction skipped.")
                if not any(i.content_type == "text" for i in items) and ocr_enabled:
                    warnings.append("OCR on rendered PDF pages is not enabled in this MVP; use image upload or add page rendering support.")
                elif not any(i.content_type == "text" for i in items):
                    warnings.append("No selectable text found. This may be a scanned PDF; enable OCR or provide a text-based PDF.")
            except Exception as exc:
                raise ValueError(f"Could not parse PDF: {type(exc).__name__}: {exc}") from exc
        elif ext in {".txt", ".md"}:
            try:
                text = content.decode("utf-8-sig").strip()
            except UnicodeDecodeError as exc:
                raise ValueError("Text files must be UTF-8 encoded") from exc
            if text:
                items.append(Evidence(document_id=doc_id, filename=filename, page=1, content_type="text", text=text))
        else:
            try:
                image = Image.open(io.BytesIO(content))
                image.verify()
            except Exception as exc:
                raise ValueError("Invalid or unsupported image file") from exc
            image_count = 1
            if ocr_enabled:
                try:
                    import pytesseract
                    image = Image.open(io.BytesIO(content))
                    ocr_text = pytesseract.image_to_string(image).strip()
                    if ocr_text:
                        items.append(Evidence(document_id=doc_id, filename=filename, page=1, content_type="ocr_text", text=ocr_text, metadata={"engine": "tesseract"}))
                    else:
                        warnings.append("OCR returned no text.")
                except ImportError:
                    warnings.append("OCR requested but pytesseract is not installed. Install the 'ocr' extra and Tesseract binary.")
                except Exception as exc:
                    warnings.append(f"OCR failed ({type(exc).__name__}); install/configure the Tesseract binary if needed.")
            caption = captioner.describe(content) if captioner else "Image uploaded; visual description not configured."
            items.append(Evidence(document_id=doc_id, filename=filename, page=1, content_type="image", text=caption, metadata={"caption_source": "configured_adapter" if captioner else "placeholder", "width": image.width, "height": image.height}))
        result = IngestResult(document_id=doc_id, filename=filename, pages=pages, text_items=len(items), tables=len(tables), images=image_count, warnings=warnings)
        self.documents[doc_id] = {"filename": filename, "content": content, "result": result, "tables": tables}
        self.evidence.extend(items)
        return result

    def for_document(self, document_id: str) -> list[Evidence]:
        if document_id not in self.documents:
            raise KeyError(document_id)
        return [item for item in self.evidence if item.document_id == document_id]

    def list_documents(self) -> list[dict]:
        return [{"document_id": key, "filename": value["filename"], "result": value["result"].model_dump()} for key, value in self.documents.items()]
