"""Small transparent lexical retrieval baseline with evidence-grounded abstention."""
import re
from collections import Counter
from .models import Evidence, QueryResponse
from .ingest import DocumentStore

STOPWORDS = {"the","a","an","is","are","was","were","what","which","who","when","where","how","does","do","of","to","in","on","for","and","or","with","from","this","that","it"}
def tokens(text: str) -> list[str]:
    return [t for t in re.findall(r"[a-z0-9]+", text.lower()) if t not in STOPWORDS]

def retrieve(store: DocumentStore, question: str, top_k: int = 5) -> list[Evidence]:
    q = Counter(tokens(question))
    if not q:
        return []
    ranked = []
    for item in store.evidence:
        d = Counter(tokens(item.text))
        overlap = sum(min(count, d.get(term, 0)) for term, count in q.items())
        if overlap:
            score = overlap / max(1, len(q)) + 0.15 * overlap / max(1, sum(d.values()))
            ranked.append((score, item))
    ranked.sort(key=lambda pair: (-pair[0], pair[1].filename, pair[1].page or 0))
    return [item for _, item in ranked[:top_k]]

def answer_question(store: DocumentStore, question: str, top_k: int = 5) -> QueryResponse:
    hits = retrieve(store, question, top_k)
    if not hits:
        return QueryResponse(answer="I could not find supporting evidence in the ingested documents.", evidence=[], abstained=True, message="Try a more specific question or ingest a relevant document.")
    snippets = []
    for idx, hit in enumerate(hits, 1):
        location = f"page {hit.page}" if hit.page else "page unknown"
        snippets.append(f"[{idx}] {hit.filename}, {location}, {hit.content_type}: {hit.text[:900]}")
    answer = "I found these potentially relevant passages. This baseline returns evidence rather than generating unsupported claims:\n\n" + "\n\n".join(snippets)
    return QueryResponse(answer=answer, evidence=hits, abstained=False)
