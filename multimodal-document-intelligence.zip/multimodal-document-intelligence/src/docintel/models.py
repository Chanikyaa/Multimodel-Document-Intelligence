"""Typed data structures shared by ingestion, retrieval, and API layers."""
from pydantic import BaseModel, Field

class Evidence(BaseModel):
    document_id: str
    filename: str
    page: int | None = None
    content_type: str = "text"
    text: str
    metadata: dict[str, str | int | float | bool | None] = Field(default_factory=dict)

class IngestResult(BaseModel):
    document_id: str
    filename: str
    pages: int
    text_items: int
    tables: int
    images: int
    warnings: list[str] = Field(default_factory=list)

class QueryRequest(BaseModel):
    question: str = Field(min_length=3, max_length=2000)
    top_k: int = Field(default=5, ge=1, le=20)

class QueryResponse(BaseModel):
    answer: str
    evidence: list[Evidence]
    abstained: bool
    message: str | None = None

class ExtractionRequest(BaseModel):
    document_id: str
    fields: dict[str, str] = Field(description="Map of output field name to expected type: string, number, date, boolean")

class ExtractionResponse(BaseModel):
    document_id: str
    values: dict[str, object]
    evidence: dict[str, str]
    missing_fields: list[str]
