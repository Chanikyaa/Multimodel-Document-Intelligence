# Engineering log

## 2026-10-25 — Initial implementation

- Selected FastAPI for a simple upload/query/extract interface and automatic OpenAPI docs.
- Selected pdfplumber for text/table parsing and Pillow for image validation; these are direct dependencies because they serve core parsing paths.
- Kept Tesseract optional because it requires a separate system binary and not all environments need OCR.
- Added a vision adapter boundary with explicit mock default and optional OpenAI-compatible implementation; real provider usage can cost money and sends image content externally.
- Chose in-memory storage and lexical retrieval to keep the MVP runnable offline; production persistence and semantic search are future work.
- Implemented tests and documentation; see README for actual results from the current environment.

## Next steps

1. Add rendered-page OCR for scanned PDFs.
2. Add labelled evaluation data and measure parsing/retrieval/citation quality.
3. Add persistent storage, authentication, tenant isolation, and background jobs before public deployment.
4. Add robust visual region/chart extraction only with a benchmark to verify it.
