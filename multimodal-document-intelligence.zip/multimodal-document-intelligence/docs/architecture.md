# Architecture and data flow

```mermaid
flowchart TD
  A[PDF / TXT / Markdown / Image] --> B[File and size validation]
  B --> C[Text and page extraction]
  B --> D[Table extraction]
  B --> E[Image extraction]
  E --> F[Optional OCR / vision adapter]
  C --> G[Page-aware evidence records]
  D --> G
  F --> G
  G --> H[In-memory document store]
  H --> I[Lexical retrieval]
  I --> J[Evidence-grounded response / abstention]
  H --> K[Field extraction]
  K --> L[Pydantic response validation]
```

## Boundaries

- API: FastAPI endpoints, request validation, upload size/type checks.
- Ingestion: `ingest.py` parses PDFs with pdfplumber, images with Pillow, and text files as UTF-8. PDF tables are represented as evidence records.
- Visual adapters: `vision.py` defaults to a transparent mock caption; an optional OpenAI-compatible vision API is available via environment variables.
- Retrieval: `retrieval.py` uses an intentionally simple lexical baseline and returns evidence with filenames/pages. It abstains when no evidence overlaps.
- Extraction: `extraction.py` extracts labelled fields from text and links each value to the matching source line.

## Design choices

The in-memory store avoids introducing a database before the workflow is validated. This means data is lost on restart and the service is not multi-worker safe. A production extension should use a persistent document store, tenant-aware authorization, async provider calls, durable jobs for large PDFs, and a proper retrieval index.
