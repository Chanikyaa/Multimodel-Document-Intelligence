# Evaluation plan

## Deterministic checks

- Text extraction: confirm expected page text is present.
- Table extraction: confirm table rows are surfaced as evidence.
- Page provenance: every PDF evidence item has a page number.
- OCR: optional, tested for missing dependency handling; actual OCR quality depends on Tesseract installation and scan quality.
- Visual description: mock adapter must be explicit; optional live provider requires a key and may incur cost.
- Retrieval: query terms should retrieve the expected supporting passage.
- Structured extraction: parsed values must match expected type and include source-line evidence; missing or malformed values must not be fabricated.
- Abstention: unrelated questions return no-evidence message.

## Benchmark before making quality claims

Create a labelled dataset of document questions, gold evidence pages, expected structured values, and representative scans/tables/charts. Report extraction success, evidence Recall@k, field exact match, citation/page accuracy, latency, and per-file failure rates. Segment by born-digital PDFs, scanned PDFs, tables, and images. Do not treat mock captions as vision performance. Run a separate held-out set and human review before claiming improvements.

## Known gaps

No robust chart understanding or cross-modal embedding model is bundled. OCR on PDF-rendered pages is not yet implemented. Table parsing quality depends on PDF layout. The current retrieval baseline is lexical, not semantic. These are explicit MVP limits.
