# Career readiness: Multimodal Document Intelligence

## Target roles and skills

AI Engineer, Applied AI Engineer, GenAI Engineer, Document AI Engineer, NLP Engineer. Demonstrates Python packaging, FastAPI, PDF/text parsing, table extraction, optional OCR, vision-provider abstraction, evidence provenance, retrieval, structured output validation, tests, and security trade-offs.

## Requirement-to-feature mapping

- PDF/text ingestion → `ingest.py`
- Tables and page references → pdfplumber evidence records
- Images and optional vision → `vision.py` plus image evidence
- OCR → optional Tesseract path for image files
- Retrieval and abstention → `retrieval.py`
- Structured extraction → `extraction.py` and Pydantic models
- API/demo → `api.py`, `/docs`, and browser UI
- Reproducibility → `pyproject.toml`, tests, CI

## Resume bullet templates (replace placeholders with verified results)

- Built a FastAPI document-intelligence service parsing PDF/text/image inputs and preserving page-level evidence across [N] benchmark documents.
- Implemented evidence-grounded retrieval and typed field extraction, achieving [measured exact-match / Recall@k] on a held-out labelled dataset.
- Added optional OCR and vision-provider adapters with a mock-first workflow, upload validation, and automated tests covering [N] edge cases.

## Results to measure

Number of documents/pages; parse success by format; table extraction accuracy; OCR character error rate; evidence Recall@k; field exact match; page/citation accuracy; p50/p95 latency; memory per page; provider cost per page; malformed-file failure rate.

## Five-minute demo

1. Explain evidence-first goal and architecture (30 sec).
2. Start API and open `/` or `/docs` (30 sec).
3. Upload `data/sample/report.txt`; point out document ID and parsed fields (45 sec).
4. Query the project budget; show evidence and file provenance (45 sec).
5. Call `/extract` with date, department, budget, and approval field types (60 sec).
6. Ask an unrelated question and show abstention (30 sec).
7. Explain mock vision vs optional paid vision provider, OCR dependency, and limits (60 sec).

## Two-minute architecture explanation

Uploads are validated for size and extension. Parsers convert documents into typed evidence records that retain filename, page number, and content type. PDF text and tables use pdfplumber; images can use Tesseract OCR and an optional vision API. Evidence is stored in memory and searched with a transparent lexical baseline. Answers quote retrieved evidence and abstain when nothing matches. Field extraction validates requested types and returns the matching source line for auditability. This keeps the MVP simple and inspectable, but does not yet provide semantic retrieval, durable storage, tenant isolation, or robust chart reasoning.

## Interview questions and answers

1. **Why keep page numbers?** They provide traceability so users can verify claims in the source document.
2. **Why a lexical baseline?** It is deterministic, cheap, and easy to debug before evaluating embeddings.
3. **How would you add semantic retrieval?** Embed evidence chunks, store vectors, use hybrid search, and evaluate Recall@k against labelled gold pages.
4. **How do you avoid hallucinated answers?** Return retrieved passages, state that this is not free-form generation, and abstain on no evidence. A production generator still needs groundedness evaluation.
5. **What makes OCR unreliable?** Scan resolution, skew, language, fonts, and layout; measure character error rate and retain confidence/quality metadata.
6. **Why separate OCR and vision?** OCR transcribes visible text; vision models can describe layout and visuals. Their errors and costs differ.
7. **What is the risk of sending files to a vision API?** Data leaves the local process; policy, consent, retention, and provider terms must be checked.
8. **How are tables represented?** Rows are serialized into evidence text with page and table metadata; structured table storage should be added for richer queries.
9. **How would you handle scanned PDFs?** Render pages with PyMuPDF, OCR each page, preserve page number, and add scan-specific tests.
10. **How do you validate JSON extraction?** Use explicit field schemas, parse types conservatively, return missing fields, and attach source snippets.
11. **Why no database?** This keeps setup lightweight for an MVP; production needs durable storage, indexing, tenant controls, and retention policies.
12. **How would you process 500-page PDFs?** Use background jobs, page batching, worker isolation, memory bounds, and progress state.
13. **What is prompt injection in documents?** Untrusted content may contain instructions; the application must treat it as data and never as privileged control.
14. **How do you evaluate citation accuracy?** Compare returned evidence/page references with human-labelled supporting pages and report precision/recall.
15. **What is a useful baseline?** A simple deterministic parser/retriever whose errors are understood before adding expensive models.
16. **How would you measure chart QA?** Create labelled chart questions, expected values, evidence regions/pages, and evaluate numeric accuracy plus evidence support.
17. **What does the mock provider prove?** It proves the interface and fallback flow work; it does not prove visual understanding.
18. **How would you reduce latency?** Profile parsing, cache document hashes, parallelize independent page processing carefully, and measure p95 before optimization.
19. **How do you prevent malicious uploads?** Type sniffing, size/page limits, sandboxed parsing, malware scanning, timeouts, and isolated workers.
20. **What would you improve next?** PDF page rendering + OCR, persistent storage, hybrid retrieval, real evaluation set, and auth/tenant isolation.

## Debugging/system-design scenarios

- Empty text from PDF: determine whether it is scanned, inspect page count, OCR rendered pages, and preserve warnings.
- Wrong table columns: inspect extraction output, use layout-aware parsing, and test representative layouts.
- Vision provider timeout: apply timeout/retry budgets, surface provider failure, and do not silently invent captions.
- Cross-tenant data leak: add tenant ownership to document/evidence queries and authorization tests before deploying multi-user.
- Very large PDF exhausts memory: enforce page/size limits, use streaming/background jobs and bounded batches.

## Likely objections and honest answers

- **“This isn't production-ready.”** Correct; it is a tested local MVP and lacks authentication, persistence, robust OCR for PDF pages, semantic retrieval, and deployment hardening.
- **“The mock doesn't do vision.”** Correct; mock mode tests the adapter boundary only. Live vision is optional and must be benchmarked separately.
- **“Lexical search is weak.”** Correct; it is a baseline selected for transparency, with semantic/hybrid retrieval as a measured next step.
- **“Table and chart support is incomplete.”** Correct; basic PDF table extraction is present, but robust chart understanding and complex layout handling remain future work.
