# Portfolio tracker snapshot

| Project | Target role | Core stack | Implementation | Tests | Evaluation | Deployment | GitHub |
|---|---|---|---|---|---|---|---|
| 1. Hybrid Search RAG | GenAI / AI Engineer | Python, retrieval, RAG | Previously implemented MVP | Previously reported passing | Benchmark work pending | Local | Not published |
| 2. Tool-Calling Agent | AI Engineer | Tools, schemas, orchestration | Previously implemented MVP | Previously reported passing | Agent benchmark pending | Local | Not published |
| 3. MCP Server | AI Engineer | MCP SDK | Updated MVP | 11 passed, 1 skipped | Protocol test skipped pending SDK availability | Local | Not published |
| 4. Production LLM API | Backend / GenAI | FastAPI, Pydantic | MVP | 11 passed | Live-provider benchmark pending | Local | Not published |
| 5. LLM Evaluation Pipeline | AI Quality / GenAI | Python, pytest, metrics | MVP | Previously reported passing | Synthetic fixture only | Local | Not published |
| 6. Multimodal Document Intelligence | Document AI / Applied AI | FastAPI, pdfplumber, Pillow, optional OCR/vision | MVP | See current test run | Labelled benchmark pending | Local | Not published |

Update each row after rerunning tests and collecting real benchmark results. This file is a working snapshot, not a claim of external deployment or publication.
