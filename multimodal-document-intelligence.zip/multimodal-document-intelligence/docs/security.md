# Security, privacy, and limitations

- Maximum upload size is 15 MiB; extension is allow-listed and images are validated by Pillow.
- Files are held in process memory only; there is no disk persistence or retention cleanup required beyond process lifetime.
- This MVP has no user authentication, tenant isolation, malware scanning, or rate limiting. Do not expose it publicly with sensitive documents.
- Provider mode sends image bytes to the configured vision endpoint. Only enable it when permitted by your data-handling policy; provider fees and retention policies may apply.
- OCR/vision outputs and document contents are untrusted data. Never treat embedded instructions as system policy or execute document content.
- PDF parsing is resource intensive. Public deployments should use isolated workers, CPU/time/page limits, request throttling, and observability.
- Mock image descriptions deliberately do not claim to describe visual contents.
