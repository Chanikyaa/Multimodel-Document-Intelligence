from docintel.ingest import DocumentStore
from docintel.retrieval import answer_question, retrieve

def test_retrieves_supporting_evidence_and_preserves_source():
    store = DocumentStore()
    result = store.ingest("report.txt", b"Project budget: 125000\nDepartment: Applied Research")
    hits = retrieve(store, "What is the project budget?", 3)
    assert hits and hits[0].document_id == result.document_id
    answer = answer_question(store, "project budget")
    assert not answer.abstained
    assert "125000" in answer.answer

def test_abstains_without_evidence():
    store = DocumentStore()
    store.ingest("report.txt", b"Project budget: 125000")
    answer = answer_question(store, "What is the capital of Mars?")
    assert answer.abstained
    assert answer.evidence == []
