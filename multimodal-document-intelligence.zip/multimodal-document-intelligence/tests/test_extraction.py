from docintel.ingest import DocumentStore
from docintel.extraction import extract_fields
import pytest

def test_extracts_typed_fields_with_source_evidence():
    store = DocumentStore()
    result = store.ingest("report.txt", b"Report date: 2026-09-30\nDepartment: Applied Research\nProject budget: 125000\nApproved: yes")
    extracted = extract_fields(store, result.document_id, {"Report date":"date", "Department":"string", "Project budget":"number", "Approved":"boolean", "Owner":"string"})
    assert extracted.values == {"Report date":"2026-09-30", "Department":"Applied Research", "Project budget":125000, "Approved":True}
    assert extracted.missing_fields == ["Owner"]
    assert "Project budget" in extracted.evidence

def test_unsupported_type_rejected():
    store = DocumentStore()
    result = store.ingest("report.txt", b"Field: value")
    with pytest.raises(ValueError, match="Unsupported type"):
        extract_fields(store, result.document_id, {"Field":"object"})
