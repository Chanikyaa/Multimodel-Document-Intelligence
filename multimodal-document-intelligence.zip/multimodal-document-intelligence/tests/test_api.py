from fastapi.testclient import TestClient
from docintel.api import app, store

client = TestClient(app)

def setup_function():
    store.documents.clear()
    store.evidence.clear()

def test_health_and_upload_query_extract_flow():
    assert client.get("/health").json()["status"] == "ok"
    uploaded = client.post("/documents", files={"file":("report.txt", b"Project budget: 125000\nApproved: yes", "text/plain")})
    assert uploaded.status_code == 200, uploaded.text
    doc_id = uploaded.json()["document_id"]
    query = client.post("/query", json={"question":"project budget", "top_k":3})
    assert query.status_code == 200
    assert "125000" in query.json()["answer"]
    extracted = client.post("/extract", json={"document_id":doc_id,"fields":{"Project budget":"number","Approved":"boolean"}})
    assert extracted.status_code == 200
    assert extracted.json()["values"] == {"Project budget":125000,"Approved":True}

def test_bad_extension_rejected():
    response = client.post("/documents", files={"file":("payload.exe", b"bad", "application/octet-stream")})
    assert response.status_code == 400

def test_unknown_document_extraction_returns_404():
    response = client.post("/extract", json={"document_id":"missing","fields":{"Name":"string"}})
    assert response.status_code == 404
