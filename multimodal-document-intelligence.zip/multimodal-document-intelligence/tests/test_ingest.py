from io import BytesIO
from pathlib import Path
import pytest
from reportlab.pdfgen import canvas
from docintel.ingest import DocumentStore


def make_pdf(text="Report date: 2026-09-30\nProject budget: 125000"):
    output = BytesIO()
    pdf = canvas.Canvas(output)
    for line_no, line in enumerate(text.split("\n")):
        pdf.drawString(72, 750 - 18 * line_no, line)
    pdf.save()
    return output.getvalue()


def test_text_ingestion_and_deterministic_id():
    store = DocumentStore()
    first = store.ingest("sample.txt", b"Hello evidence world")
    second = store.ingest("sample.txt", b"Hello evidence world")
    assert first.document_id == second.document_id
    assert len(store.for_document(first.document_id)) == 1
    assert store.for_document(first.document_id)[0].text == "Hello evidence world"


def test_pdf_page_text_and_provenance():
    store = DocumentStore()
    result = store.ingest("report.pdf", make_pdf())
    assert result.pages == 1
    items = store.for_document(result.document_id)
    assert any("Project budget: 125000" in item.text for item in items)
    assert all(item.page == 1 for item in items)


def test_reject_unsupported_empty_and_oversized():
    store = DocumentStore()
    with pytest.raises(ValueError, match="Unsupported"):
        store.ingest("file.exe", b"no")
    with pytest.raises(ValueError, match="empty"):
        store.ingest("empty.txt", b"")
    with pytest.raises(ValueError, match="15 MiB"):
        store.ingest("large.txt", b"x" * (15 * 1024 * 1024 + 1))


def test_invalid_image_rejected():
    store = DocumentStore()
    with pytest.raises(ValueError, match="Invalid"):
        store.ingest("broken.png", b"not an image")
