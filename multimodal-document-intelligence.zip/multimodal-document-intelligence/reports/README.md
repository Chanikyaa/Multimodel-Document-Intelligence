Generated evaluation reports belong here. No benchmark results are committed as facts before running a labelled evaluation.
